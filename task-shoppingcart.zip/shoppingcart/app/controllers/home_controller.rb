class HomeController < ApplicationController
before_action:authenticate,except:[:customer,:display]
  def admin
  end

  def customer
  @categories=Category.all
  end
def display
 @category=Category.find(params[:id])
 @products=@category.products
end
end
