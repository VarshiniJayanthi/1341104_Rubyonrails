Rails.application.routes.draw do
  

  get 'display:id'=>"home#display",as:"display"
  root to:'home#customer'
  get 'home/admin'

   resources :products
  resources :categories
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
